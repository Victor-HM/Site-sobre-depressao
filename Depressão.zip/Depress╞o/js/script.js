const card = document.querySelector("#card")
card.addEventListener("click",(e)=>{
    card.classList.toggle("flip")
})